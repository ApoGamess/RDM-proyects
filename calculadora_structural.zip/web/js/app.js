import { modules } from "./modules-data.js";
import { getUnitOptions, solveModule } from "./engineering.js";
import { renderVisual } from "./visualizations.js";

const state = {
  selectedModuleId: modules[0].id,
  showDevelopment: true,
  lastResult: null,
};

const elements = {
  moduleList: document.querySelector("#module-list"),
  moduleTitle: document.querySelector("#module-title"),
  moduleDescription: document.querySelector("#module-description"),
  moduleTag: document.querySelector("#module-tag"),
  form: document.querySelector("#calculator-form"),
  errorBox: document.querySelector("#error-box"),
  resultBox: document.querySelector("#result-box"),
  visualBox: document.querySelector("#visual-box"),
  learningBox: document.querySelector("#learning-box"),
  calculateButton: document.querySelector("#calculate-button"),
  resetButton: document.querySelector("#reset-button"),
  toggleDevelopmentButton: document.querySelector("#toggle-development-button"),
};

const getSelectedModule = () => modules.find((module) => module.id === state.selectedModuleId);

const createField = (field, moduleConfig) => {
  const wrapper = document.createElement("div");
  wrapper.className = `field ${field.fullWidth ? "full-width" : ""}`;

  const label = document.createElement("label");
  label.setAttribute("for", field.name);
  label.textContent = field.label;

  let control;
  if (field.type === "select") {
    control = document.createElement("select");
    control.name = field.name;
    control.id = field.name;
    (field.options || []).forEach((option) => {
      const optionElement = document.createElement("option");
      optionElement.value = option.value;
      optionElement.textContent = option.label;
      control.append(optionElement);
    });
  } else {
    control = document.createElement("input");
    control.type = field.type;
    control.name = field.name;
    control.id = field.name;
    control.placeholder = field.placeholder || "";
    control.step = field.step || "any";
    control.inputMode = "decimal";
  }

  const helper = document.createElement("p");
  helper.className = "helper-text";
  helper.textContent = field.unit ? `Unidad esperada: ${field.unit}` : "Selecciona una opción";

  wrapper.append(label, control, helper);

  if (moduleConfig.id === "beam" && field.name === "position") {
    wrapper.dataset.conditional = "point-only";
  }

  return wrapper;
};

const renderModuleList = () => {
  elements.moduleList.innerHTML = "";

  modules.forEach((moduleConfig) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `module-card ${moduleConfig.id === state.selectedModuleId ? "active" : ""}`;
    button.innerHTML = `<strong>${moduleConfig.name}</strong><span>${moduleConfig.description}</span>`;
    button.addEventListener("click", () => {
      state.selectedModuleId = moduleConfig.id;
      state.lastResult = null;
      renderApp();
    });
    elements.moduleList.append(button);
  });
};

const renderForm = () => {
  const moduleConfig = getSelectedModule();
  elements.form.innerHTML = "";
  elements.form.dataset.moduleId = moduleConfig.id;

  const infoStrip = document.createElement("div");
  infoStrip.className = "info-strip";
  moduleConfig.formulas.forEach((formula) => {
    const chip = document.createElement("span");
    chip.className = "formula-chip";
    chip.textContent = formula;
    infoStrip.append(chip);
  });

  const grid = document.createElement("div");
  grid.className = "form-grid";
  moduleConfig.fields.forEach((field) => {
    grid.append(createField(field, moduleConfig));
  });

  elements.form.append(infoStrip, grid);

  if (moduleConfig.id === "conversion") {
    syncConversionUnits();
  }

  if (moduleConfig.id === "beam") {
    syncBeamFieldVisibility();
  }

  elements.form.onchange = handleFormDependencies;
  elements.form.oninput = handleFormDependencies;
};

const getFormValues = () => {
  const formData = new FormData(elements.form);
  return Object.fromEntries(formData.entries());
};

const showError = (message) => {
  elements.errorBox.textContent = message;
  elements.errorBox.classList.remove("hidden");
};

const clearError = () => {
  elements.errorBox.textContent = "";
  elements.errorBox.classList.add("hidden");
};

const syncBeamFieldVisibility = () => {
  const loadType = elements.form.querySelector('[name="loadType"]')?.value;
  const positionField = elements.form.querySelector('[data-conditional="point-only"]');
  if (!positionField) {
    return;
  }

  positionField.style.display = loadType === "point" ? "grid" : "none";
};

const syncConversionUnits = () => {
  const category = elements.form.querySelector('[name="category"]')?.value || "force";
  const units = getUnitOptions(category);
  const fromSelect = elements.form.querySelector('[name="fromUnit"]');
  const toSelect = elements.form.querySelector('[name="toUnit"]');

  [fromSelect, toSelect].forEach((select, index) => {
    select.innerHTML = "";
    units.forEach((unit, unitIndex) => {
      const option = document.createElement("option");
      option.value = unit;
      option.textContent = unit;
      if (unitIndex === (index === 0 ? 0 : Math.min(1, units.length - 1))) {
        option.selected = true;
      }
      select.append(option);
    });
  });
};

const handleFormDependencies = (event) => {
  if (event.target.name === "category" && getSelectedModule().id === "conversion") {
    syncConversionUnits();
  }

  if (event.target.name === "loadType" && getSelectedModule().id === "beam") {
    syncBeamFieldVisibility();
  }
};

const buildMetricsMarkup = (metrics) => `
  <div class="metrics-grid">
    ${metrics.map((metric) => `
      <div class="metric-card">
        <p class="metric-label">${metric.label}</p>
        <div class="metric-value">${metric.value}</div>
      </div>
    `).join("")}
  </div>
`;

const buildExplanationMarkup = (explanation) => `
  <div class="explanation-grid">
    <div class="explanation-card">
      <h4>Fórmula general</h4>
      <p class="formula-text">${explanation.general}</p>
    </div>
    <div class="explanation-card">
      <h4>Sustitución de valores</h4>
      <p class="formula-text">${explanation.substitution}</p>
    </div>
    <div class="explanation-card">
      <h4>Resolución paso a paso</h4>
      <p>${explanation.steps.join("<br />")}</p>
    </div>
    <div class="explanation-card">
      <h4>Resultado final</h4>
      <p class="formula-text">${explanation.finalResult}</p>
      <div class="pill">Precisión apta para cálculos preliminares</div>
    </div>
  </div>
  <div class="explanation-card">
    <h4>Interpretación del resultado</h4>
    <p>${explanation.interpretation}</p>
  </div>
`;

const renderResult = () => {
  const result = state.lastResult;
  if (!result) {
    elements.resultBox.className = "result-box empty-state";
    elements.resultBox.textContent = "Completa los datos y presiona “Calcular” para ver el resultado.";
    return;
  }

  elements.resultBox.className = "result-box";
  elements.resultBox.innerHTML = `
    <div class="result-highlight">
      <p class="section-kicker">Resultado principal</p>
      <strong>${result.headline}</strong>
      <p>${result.summary}</p>
    </div>
    ${buildMetricsMarkup(result.metrics)}
    ${state.showDevelopment ? buildExplanationMarkup(result.explanation) : ""}
  `;
};

const renderLearning = () => {
  const moduleConfig = getSelectedModule();
  // Each module includes a solved example so the learning mode stays driven by metadata.
  const exampleValues = moduleConfig.theory.example;
  const exampleResult = solveModule(moduleConfig.id, exampleValues);

  elements.learningBox.innerHTML = `
    <div class="learning-grid">
      <div class="learning-card-block">
        <h4>Teoría breve</h4>
        <p>${moduleConfig.theory.summary}</p>
      </div>
      <div class="learning-card-block">
        <h4>Cuándo se usa</h4>
        <p>${moduleConfig.theory.usage}</p>
      </div>
      <div class="learning-card-block">
        <h4>Variables</h4>
        <p>${moduleConfig.theory.variables.join("<br />")}</p>
      </div>
      <div class="learning-card-block">
        <h4>Ejemplo resuelto</h4>
        <p>${exampleResult.explanation.general}</p>
        <p>${exampleResult.explanation.substitution}</p>
        <p><strong>${exampleResult.explanation.finalResult}</strong></p>
      </div>
    </div>
  `;
};

const renderHeader = () => {
  const moduleConfig = getSelectedModule();
  elements.moduleTitle.textContent = moduleConfig.name;
  elements.moduleDescription.textContent = moduleConfig.description;
  elements.moduleTag.textContent = moduleConfig.badge;
  elements.toggleDevelopmentButton.textContent = state.showDevelopment ? "Ocultar desarrollo" : "Mostrar desarrollo";
};

const handleCalculate = () => {
  clearError();
  try {
    const formValues = getFormValues();
    state.lastResult = solveModule(state.selectedModuleId, formValues);
    renderResult();
    renderVisual(elements.visualBox, state.lastResult.visual);
  } catch (error) {
    state.lastResult = null;
    renderResult();
    renderVisual(elements.visualBox, null);
    showError(error.message || "No fue posible completar el cálculo.");
  }
};

const resetForm = () => {
  elements.form.reset();
  clearError();
  state.lastResult = null;
  renderResult();
  renderVisual(elements.visualBox, null);
  if (state.selectedModuleId === "conversion") {
    syncConversionUnits();
  }
  if (state.selectedModuleId === "beam") {
    syncBeamFieldVisibility();
  }
};

const renderApp = () => {
  renderModuleList();
  renderHeader();
  renderForm();
  renderLearning();
  clearError();
  renderResult();
  renderVisual(elements.visualBox, null);
};

elements.calculateButton.addEventListener("click", handleCalculate);
elements.resetButton.addEventListener("click", resetForm);
elements.toggleDevelopmentButton.addEventListener("click", () => {
  state.showDevelopment = !state.showDevelopment;
  renderHeader();
  renderResult();
});
elements.form?.addEventListener("submit", (event) => event.preventDefault());

renderApp();
