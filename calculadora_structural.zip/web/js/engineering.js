const UNIT_FACTORS = {
  force: { N: 1, kN: 1000 },
  length: { mm: 0.001, cm: 0.01, m: 1 },
  pressure: { Pa: 1, MPa: 1_000_000, GPa: 1_000_000_000 },
};

const requireFinite = (value, label) => {
  if (!Number.isFinite(value)) {
    throw new Error(`${label} debe ser numérico.`);
  }
};

const roundValue = (value, decimals = 6) => {
  if (!Number.isFinite(value)) {
    return value;
  }

  if (Math.abs(value) >= 1_000_000 || (Math.abs(value) > 0 && Math.abs(value) < 0.001)) {
    return Number(value.toExponential(6));
  }

  return Number(value.toFixed(decimals));
};

export const formatNumber = (value, decimals = 6) => {
  if (!Number.isFinite(value)) {
    return "No disponible";
  }

  if (Math.abs(value) >= 1_000_000 || (Math.abs(value) > 0 && Math.abs(value) < 0.001)) {
    return value.toExponential(4);
  }

  return value.toLocaleString("es-ES", {
    minimumFractionDigits: 0,
    maximumFractionDigits: decimals,
  });
};

const requirePositive = (value, label) => {
  if (!Number.isFinite(value) || value <= 0) {
    throw new Error(`${label} debe ser mayor que cero.`);
  }
};

const requireNonZero = (value, label) => {
  if (!Number.isFinite(value) || value === 0) {
    throw new Error(`${label} no puede ser cero.`);
  }
};

const buildExplanation = ({ general, substitution, steps, finalResult, interpretation }) => ({
  general,
  substitution,
  steps,
  finalResult,
  interpretation,
});

const samplePoints = (count, mapper) => Array.from({ length: count }, (_, index) => mapper(index / (count - 1)));

const toNumberMap = (rawValues) => Object.fromEntries(
  Object.entries(rawValues).map(([key, value]) => [key, value === "" ? "" : Number(value)]),
);

const calculateStress = (rawValues) => {
  const values = toNumberMap(rawValues);
  requireFinite(values.force, "La fuerza F");
  requirePositive(values.area, "El área A");

  const sigma = values.force / values.area;

  return {
    moduleId: "normal-stress",
    headline: `sigma = ${formatNumber(sigma)} Pa`,
    summary: "El elemento desarrolla un esfuerzo axial uniforme asociado a la carga aplicada y al área resistente.",
    metrics: [
      { label: "Esfuerzo normal sigma", value: `${formatNumber(sigma)} Pa` },
      { label: "Equivalente", value: `${formatNumber(sigma / 1_000_000)} MPa` },
      { label: "Fuerza ingresada", value: `${formatNumber(values.force)} N` },
      { label: "Área ingresada", value: `${formatNumber(values.area)} m²` },
    ],
    explanation: buildExplanation({
      general: "sigma = F / A",
      substitution: `sigma = ${formatNumber(values.force)} N / ${formatNumber(values.area)} m²`,
      steps: [
        "1. Identificar la carga axial y el área efectiva.",
        "2. Dividir la fuerza por el área para obtener el esfuerzo promedio.",
        `3. Resultado numérico: sigma = ${formatNumber(sigma)} Pa.`,
      ],
      finalResult: `sigma = ${formatNumber(sigma)} Pa = ${formatNumber(sigma / 1_000_000)} MPa`,
      interpretation: "Si el valor supera la tensión admisible del material, la sección no sería adecuada para esta carga.",
    }),
    visual: {
      type: "stressBar",
      payload: {
        force: values.force,
        area: values.area,
        stress: sigma,
      },
    },
  };
};

const calculateStrain = (rawValues) => {
  const values = toNumberMap(rawValues);
  requireFinite(values.deltaL, "El cambio de longitud deltaL");
  requirePositive(values.length, "La longitud inicial L");

  const epsilon = values.deltaL / values.length;

  return {
    moduleId: "strain",
    headline: `epsilon = ${formatNumber(epsilon)}`,
    summary: "La deformación unitaria indica la proporción de alargamiento respecto a la longitud original.",
    metrics: [
      { label: "Deformación epsilon", value: `${formatNumber(epsilon)}` },
      { label: "Cambio de longitud", value: `${formatNumber(values.deltaL)} m` },
      { label: "Longitud inicial", value: `${formatNumber(values.length)} m` },
      { label: "Porcentaje", value: `${formatNumber(epsilon * 100)} %` },
    ],
    explanation: buildExplanation({
      general: "epsilon = deltaL / L",
      substitution: `epsilon = ${formatNumber(values.deltaL)} m / ${formatNumber(values.length)} m`,
      steps: [
        "1. Verificar que ambas longitudes estén en las mismas unidades.",
        "2. Dividir el cambio de longitud entre la longitud inicial.",
        `3. La deformación obtenida es adimensional: epsilon = ${formatNumber(epsilon)}.`,
      ],
      finalResult: `epsilon = ${formatNumber(epsilon)} (${formatNumber(epsilon * 100)} %)`,
      interpretation: "Valores pequeños suelen corresponder al régimen elástico; valores altos pueden indicar deformación significativa.",
    }),
    visual: {
      type: "strainGauge",
      payload: {
        deltaL: values.deltaL,
        length: values.length,
        strain: epsilon,
      },
    },
  };
};

const calculateHooke = (rawValues) => {
  const values = toNumberMap(rawValues);
  const solveFor = rawValues.solveFor;

  let result;
  let general;
  let substitution;
  let finalResult;

  if (solveFor === "sigma") {
    requirePositive(values.E, "El módulo E");
    requireFinite(values.epsilon, "La deformación epsilon");
    result = values.E * values.epsilon;
    general = "sigma = E * epsilon";
    substitution = `sigma = ${formatNumber(values.E)} Pa * ${formatNumber(values.epsilon)}`;
    finalResult = `sigma = ${formatNumber(result)} Pa`;
  } else if (solveFor === "E") {
    requireFinite(values.sigma, "El esfuerzo sigma");
    requireNonZero(values.epsilon, "La deformación epsilon");
    result = values.sigma / values.epsilon;
    general = "E = sigma / epsilon";
    substitution = `E = ${formatNumber(values.sigma)} Pa / ${formatNumber(values.epsilon)}`;
    finalResult = `E = ${formatNumber(result)} Pa = ${formatNumber(result / 1_000_000_000)} GPa`;
  } else {
    requireFinite(values.sigma, "El esfuerzo sigma");
    requirePositive(values.E, "El módulo E");
    result = values.sigma / values.E;
    general = "epsilon = sigma / E";
    substitution = `epsilon = ${formatNumber(values.sigma)} Pa / ${formatNumber(values.E)} Pa`;
    finalResult = `epsilon = ${formatNumber(result)}`;
  }

  return {
    moduleId: "hooke-law",
    headline: `${solveFor} = ${formatNumber(result)}`,
    summary: "La relación lineal entre esfuerzo y deformación permite resolver la variable faltante en materiales elásticos.",
    metrics: [
      { label: "Variable despejada", value: solveFor },
      { label: "Resultado", value: finalResult.replace(`${solveFor} = `, "") },
      { label: "Esfuerzo sigma", value: rawValues.sigma ? `${formatNumber(values.sigma)} Pa` : "No ingresado" },
      { label: "Módulo E", value: rawValues.E ? `${formatNumber(values.E)} Pa` : "No ingresado" },
      { label: "Deformación epsilon", value: rawValues.epsilon ? `${formatNumber(values.epsilon)}` : "No ingresado" },
    ],
    explanation: buildExplanation({
      general,
      substitution,
      steps: [
        "1. Seleccionar la variable que se desea despejar.",
        "2. Reordenar la ecuación de Hooke manteniendo consistencia de unidades.",
        `3. Sustituir los valores conocidos y resolver: ${finalResult}.`,
      ],
      finalResult,
      interpretation: "El cálculo es válido en comportamiento lineal elástico. Si el material plastifica, esta relación deja de ser suficiente.",
    }),
    visual: {
      type: "hookeLine",
      payload: {
        solveFor,
        sigma: solveFor === "sigma" ? result : values.sigma,
        E: solveFor === "E" ? result : values.E,
        epsilon: solveFor === "epsilon" ? result : values.epsilon,
      },
    },
  };
};

const calculateMoment = (rawValues) => {
  const values = toNumberMap(rawValues);
  requireFinite(values.force, "La fuerza F");
  requirePositive(values.distance, "La distancia d");

  const moment = values.force * values.distance;

  return {
    moduleId: "moment",
    headline: `M = ${formatNumber(moment)} N*m`,
    summary: "El momento crece tanto con la magnitud de la fuerza como con el brazo de palanca perpendicular.",
    metrics: [
      { label: "Momento M", value: `${formatNumber(moment)} N*m` },
      { label: "Fuerza F", value: `${formatNumber(values.force)} N` },
      { label: "Brazo d", value: `${formatNumber(values.distance)} m` },
      { label: "Equivalente", value: `${formatNumber(moment / 1000)} kN*m` },
    ],
    explanation: buildExplanation({
      general: "M = F * d",
      substitution: `M = ${formatNumber(values.force)} N * ${formatNumber(values.distance)} m`,
      steps: [
        "1. Ubicar el punto de giro o referencia.",
        "2. Medir la distancia perpendicular desde ese punto hasta la línea de acción de la fuerza.",
        `3. Multiplicar F por d para obtener el momento: M = ${formatNumber(moment)} N*m.`,
      ],
      finalResult: `M = ${formatNumber(moment)} N*m`,
      interpretation: "Un mayor brazo de palanca produce más capacidad de giro incluso si la fuerza se mantiene constante.",
    }),
    visual: {
      type: "lever",
      payload: {
        force: values.force,
        distance: values.distance,
        moment,
      },
    },
  };
};

const buildBeamArrays = ({ span, reactionA, reactionB, loadType, load, position }) => {
  // Sample points are enough here to draw smooth engineering diagrams without extra dependencies.
  const points = samplePoints(81, (ratio) => {
    const x = ratio * span;
    let shear;
    let moment;

    if (loadType === "point") {
      shear = x < position ? reactionA : reactionA - load;
      moment = x <= position ? reactionA * x : reactionA * x - load * (x - position);
    } else {
      shear = reactionA - load * x;
      moment = reactionA * x - (load * x * x) / 2;
    }

    return { x: roundValue(x, 4), shear: roundValue(shear, 6), moment: roundValue(moment, 6) };
  });

  return points;
};

const calculateBeam = (rawValues) => {
  const values = toNumberMap(rawValues);
  const loadType = rawValues.loadType;
  requirePositive(values.span, "La luz L");
  requirePositive(values.load, "La carga");

  let reactionA;
  let reactionB;
  let maxMoment;
  let substitution;
  let steps;

  if (loadType === "point") {
    requirePositive(values.position, "La posición de la carga");
    if (values.position >= values.span) {
      throw new Error("La posición de la carga puntual debe estar dentro de la luz de la viga.");
    }
    reactionA = (values.load * (values.span - values.position)) / values.span;
    reactionB = (values.load * values.position) / values.span;
    maxMoment = reactionA * values.position;
    substitution = `RA = P*(L-a)/L, RB = P*a/L = ${formatNumber(values.load)}*(${formatNumber(values.span)}-${formatNumber(values.position)})/${formatNumber(values.span)}`;
    steps = [
      "1. Aplicar equilibrio vertical: RA + RB = P.",
      "2. Tomar momentos respecto del apoyo izquierdo para obtener RB.",
      "3. Calcular RA por equilibrio y luego construir los diagramas por tramos.",
    ];
  } else {
    reactionA = (values.load * values.span) / 2;
    reactionB = reactionA;
    maxMoment = (values.load * values.span * values.span) / 8;
    substitution = `RA = RB = w*L/2 = ${formatNumber(values.load)}*${formatNumber(values.span)}/2`;
    steps = [
      "1. Calcular la carga total equivalente wL.",
      "2. Como la carga es simétrica, ambas reacciones son iguales.",
      "3. Obtener V(x) y M(x) desde las ecuaciones continuas de cortante y momento.",
    ];
  }

  const beamPoints = buildBeamArrays({
    span: values.span,
    reactionA,
    reactionB,
    loadType,
    load: values.load,
    position: values.position,
  });

  return {
    moduleId: "beam",
    headline: `RA = ${formatNumber(reactionA)} N, RB = ${formatNumber(reactionB)} N`,
    summary: "La viga simplemente apoyada transforma las cargas externas en reacciones y esfuerzos internos que varían a lo largo de la luz.",
    metrics: [
      { label: "Reacción izquierda RA", value: `${formatNumber(reactionA)} N` },
      { label: "Reacción derecha RB", value: `${formatNumber(reactionB)} N` },
      { label: "Momento máximo", value: `${formatNumber(maxMoment)} N*m` },
      { label: "Tipo de carga", value: loadType === "point" ? "Puntual" : "Distribuida uniforme" },
    ],
    explanation: buildExplanation({
      general: loadType === "point" ? "RA + RB = P y sumatoria de momentos = 0" : "RA = RB = wL/2; Mmax = wL²/8",
      substitution,
      steps,
      finalResult: `RA = ${formatNumber(reactionA)} N, RB = ${formatNumber(reactionB)} N, Mmax = ${formatNumber(maxMoment)} N*m`,
      interpretation: "El diagrama de cortante muestra saltos o pendientes según el tipo de carga, y el diagrama de momento identifica la zona crítica de flexión.",
    }),
    visual: {
      type: "beam",
      payload: {
        span: values.span,
        load: values.load,
        position: values.position,
        loadType,
        reactionA,
        reactionB,
        points: beamPoints,
      },
    },
  };
};

const calculateDeflection = (rawValues) => {
  const values = toNumberMap(rawValues);
  requirePositive(values.load, "La carga P");
  requirePositive(values.span, "La luz L");
  requirePositive(values.elasticity, "El módulo E");
  requirePositive(values.inertia, "El momento de inercia I");

  const delta = (values.load * values.span ** 3) / (48 * values.elasticity * values.inertia);

  return {
    moduleId: "deflection",
    headline: `delta = ${formatNumber(delta)} m`,
    summary: "La flecha máxima depende fuertemente de la luz, por lo que pequeñas variaciones en L producen cambios relevantes en deformación.",
    metrics: [
      { label: "Deflexión máxima", value: `${formatNumber(delta)} m` },
      { label: "Equivalente", value: `${formatNumber(delta * 1000)} mm` },
      { label: "Rigidez EI", value: `${formatNumber(values.elasticity * values.inertia)} N*m²` },
      { label: "Relación L/delta", value: `${formatNumber(values.span / delta)}` },
    ],
    explanation: buildExplanation({
      general: "delta = (P * L^3) / (48 * E * I)",
      substitution: `delta = (${formatNumber(values.load)} * ${formatNumber(values.span)}^3) / (48 * ${formatNumber(values.elasticity)} * ${formatNumber(values.inertia)})`,
      steps: [
        "1. Elevar la luz al cubo para representar su influencia en la deformación.",
        "2. Multiplicar E por I para obtener la rigidez flexional.",
        `3. Dividir el numerador entre 48EI para obtener la flecha máxima: delta = ${formatNumber(delta)} m.`,
      ],
      finalResult: `delta = ${formatNumber(delta)} m = ${formatNumber(delta * 1000)} mm`,
      interpretation: "Si la relación L/delta es baja, la viga puede presentar problemas de servicio aunque resista la carga en términos de tensión.",
    }),
    visual: {
      type: "deflection",
      payload: {
        span: values.span,
        delta,
      },
    },
  };
};

const calculateInertia = (rawValues) => {
  const values = toNumberMap(rawValues);
  const shape = rawValues.shape;

  let inertia;
  let general;
  let substitution;
  let dimensions;

  if (shape === "rectangle") {
    requirePositive(values.base, "La base b");
    requirePositive(values.height, "La altura h");
    inertia = (values.base * values.height ** 3) / 12;
    general = "I = b*h^3/12";
    substitution = `I = ${formatNumber(values.base)}*${formatNumber(values.height)}^3/12`;
    dimensions = `${formatNumber(values.base)} m x ${formatNumber(values.height)} m`;
  } else if (shape === "circle") {
    requirePositive(values.diameter, "El diámetro d");
    inertia = (Math.PI * values.diameter ** 4) / 64;
    general = "I = pi*d^4/64";
    substitution = `I = pi*${formatNumber(values.diameter)}^4/64`;
    dimensions = `d = ${formatNumber(values.diameter)} m`;
  } else {
    requirePositive(values.base, "La base b");
    requirePositive(values.height, "La altura h");
    inertia = (values.base * values.height ** 3) / 36;
    general = "I = b*h^3/36";
    substitution = `I = ${formatNumber(values.base)}*${formatNumber(values.height)}^3/36`;
    dimensions = `${formatNumber(values.base)} m x ${formatNumber(values.height)} m`;
  }

  return {
    moduleId: "inertia",
    headline: `I = ${formatNumber(inertia)} m^4`,
    summary: "Secciones más altas o diámetros mayores incrementan de forma marcada la rigidez a flexión.",
    metrics: [
      { label: "Momento de inercia", value: `${formatNumber(inertia)} m^4` },
      { label: "Sección", value: shape === "rectangle" ? "Rectángulo" : shape === "circle" ? "Círculo" : "Triángulo" },
      { label: "Dimensiones", value: dimensions },
      { label: "Equivalente", value: `${formatNumber(inertia * 1_000_000_000_000)} mm^4` },
    ],
    explanation: buildExplanation({
      general,
      substitution,
      steps: [
        "1. Seleccionar la fórmula correspondiente a la geometría.",
        "2. Sustituir las dimensiones manteniendo unidades coherentes.",
        `3. Resolver la expresión para obtener I = ${formatNumber(inertia)} m^4.`,
      ],
      finalResult: `I = ${formatNumber(inertia)} m^4`,
      interpretation: "A mayor momento de inercia, menor curvatura y menor deflexión para una misma carga.",
    }),
    visual: {
      type: "inertiaShape",
      payload: {
        shape,
        base: values.base,
        height: values.height,
        diameter: values.diameter,
      },
    },
  };
};

const buildConversionUnits = (category) => {
  const map = {
    force: ["N", "kN"],
    length: ["mm", "cm", "m"],
    pressure: ["Pa", "MPa", "GPa"],
  };
  return map[category] ?? [];
};

const calculateConversion = (rawValues) => {
  const values = toNumberMap(rawValues);
  const category = rawValues.category;
  const factors = UNIT_FACTORS[category];
  const units = buildConversionUnits(category);

  if (!factors) {
    throw new Error("Selecciona una magnitud válida para convertir.");
  }
  if (!units.includes(rawValues.fromUnit) || !units.includes(rawValues.toUnit)) {
    throw new Error("Selecciona unidades válidas de entrada y salida.");
  }
  if (!Number.isFinite(values.value)) {
    throw new Error("El valor a convertir debe ser numérico.");
  }

  const baseValue = values.value * factors[rawValues.fromUnit];
  const converted = baseValue / factors[rawValues.toUnit];

  return {
    moduleId: "conversion",
    headline: `${formatNumber(values.value)} ${rawValues.fromUnit} = ${formatNumber(converted)} ${rawValues.toUnit}`,
    summary: "La conversión mantiene la misma magnitud física y solo transforma la escala de representación.",
    metrics: [
      { label: "Valor de entrada", value: `${formatNumber(values.value)} ${rawValues.fromUnit}` },
      { label: "Valor convertido", value: `${formatNumber(converted)} ${rawValues.toUnit}` },
      { label: "Magnitud", value: category === "force" ? "Fuerza" : category === "length" ? "Longitud" : "Presión / esfuerzo" },
      { label: "Valor base SI", value: `${formatNumber(baseValue)} ${category === "force" ? "N" : category === "length" ? "m" : "Pa"}` },
    ],
    explanation: buildExplanation({
      general: "Valor convertido = valor base / factor de unidad destino",
      substitution: `${formatNumber(values.value)} ${rawValues.fromUnit} -> base SI -> ${rawValues.toUnit}`,
      steps: [
        "1. Transformar el valor de entrada a una unidad base del sistema SI.",
        "2. Dividir o multiplicar según el factor de la unidad de salida.",
        `3. Resultado final: ${formatNumber(converted)} ${rawValues.toUnit}.`,
      ],
      finalResult: `${formatNumber(values.value)} ${rawValues.fromUnit} = ${formatNumber(converted)} ${rawValues.toUnit}`,
      interpretation: "La trazabilidad de unidades reduce errores de magnitud al pasar entre escalas de trabajo.",
    }),
    visual: {
      type: "conversion",
      payload: {
        inputValue: values.value,
        inputUnit: rawValues.fromUnit,
        outputValue: converted,
        outputUnit: rawValues.toUnit,
      },
    },
  };
};

export const getUnitOptions = (category) => buildConversionUnits(category);

export const solveModule = (moduleId, values) => {
  const calculators = {
    "normal-stress": calculateStress,
    strain: calculateStrain,
    "hooke-law": calculateHooke,
    moment: calculateMoment,
    beam: calculateBeam,
    deflection: calculateDeflection,
    inertia: calculateInertia,
    conversion: calculateConversion,
  };

  const solver = calculators[moduleId];
  if (!solver) {
    throw new Error("El módulo seleccionado aún no está implementado.");
  }

  return solver(values);
};
