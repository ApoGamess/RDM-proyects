import { formatNumber } from "./engineering.js";

const clearNode = (node) => {
  node.innerHTML = "";
  node.classList.remove("empty-state");
};

const createCard = (title) => {
  const wrapper = document.createElement("div");
  wrapper.className = "visual-card-box";

  const heading = document.createElement("h4");
  heading.textContent = title;

  const stage = document.createElement("div");
  stage.className = "visual-stage";

  wrapper.append(heading, stage);
  return { wrapper, stage };
};

const makeLegend = (items) => {
  const legend = document.createElement("div");
  legend.className = "legend-row";

  items.forEach((item) => {
    const entry = document.createElement("div");
    entry.className = "legend-item";

    const swatch = document.createElement("span");
    swatch.className = "legend-swatch";
    swatch.style.background = item.color;

    const text = document.createElement("span");
    text.textContent = item.label;
    entry.append(swatch, text);
    legend.append(entry);
  });

  return legend;
};

const createSvg = (content, viewBox = "0 0 640 240") => {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("viewBox", viewBox);
  svg.setAttribute("role", "img");
  svg.innerHTML = content;
  return svg;
};

const createCanvas = (drawer, width = 640, height = 240) => {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d");
  drawer(context, width, height);
  return canvas;
};

const renderStressBar = (target, payload) => {
  const { wrapper, stage } = createCard("Distribución simplificada del esfuerzo");
  const intensity = Math.min(1, payload.stress / 20_000_000);
  const fillWidth = 120 + intensity * 380;
  stage.append(
    createSvg(`
      <rect x="90" y="80" width="460" height="80" rx="26" fill="#e7f1f0" stroke="#0d5c63" stroke-width="2" />
      <rect x="90" y="80" width="${fillWidth}" height="80" rx="26" fill="url(#stressGradient)" />
      <line x1="90" y1="60" x2="550" y2="60" stroke="#102a2b" stroke-dasharray="6 6" />
      <text x="100" y="52" fill="#102a2b" font-size="16" font-family="Trebuchet MS">F = ${formatNumber(payload.force)} N</text>
      <text x="100" y="190" fill="#102a2b" font-size="16" font-family="Trebuchet MS">A = ${formatNumber(payload.area)} m²</text>
      <text x="350" y="126" fill="#ffffff" font-size="24" text-anchor="middle" font-family="Rockwell">sigma = ${formatNumber(payload.stress / 1_000_000)} MPa</text>
      <defs>
        <linearGradient id="stressGradient" x1="0" x2="1">
          <stop offset="0%" stop-color="#0d5c63" />
          <stop offset="100%" stop-color="#4a8e84" />
        </linearGradient>
      </defs>
    `, "0 0 640 240"),
  );
  target.append(wrapper, makeLegend([{ color: "#0d5c63", label: "Intensidad del esfuerzo" }]));
};

const renderStrainGauge = (target, payload) => {
  const { wrapper, stage } = createCard("Comparación entre longitud inicial y deformada");
  const extension = Math.min(180, 40 + payload.strain * 1800);
  stage.append(
    createSvg(`
      <line x1="90" y1="100" x2="440" y2="100" stroke="#0d5c63" stroke-width="14" stroke-linecap="round" />
      <line x1="90" y1="150" x2="${440 + extension}" y2="150" stroke="#b85c38" stroke-width="14" stroke-linecap="round" />
      <text x="90" y="76" fill="#102a2b" font-size="18" font-family="Trebuchet MS">Longitud inicial L = ${formatNumber(payload.length)} m</text>
      <text x="90" y="192" fill="#102a2b" font-size="18" font-family="Trebuchet MS">Longitud final = ${formatNumber(payload.length + payload.deltaL)} m</text>
      <text x="90" y="222" fill="#4d6667" font-size="16" font-family="Trebuchet MS">deltaL = ${formatNumber(payload.deltaL)} m</text>
    `, "0 0 640 240"),
  );
  target.append(
    wrapper,
    makeLegend([
      { color: "#0d5c63", label: "Longitud inicial" },
      { color: "#b85c38", label: "Longitud deformada" },
    ]),
  );
};

const renderHooke = (target, payload) => {
  const { wrapper, stage } = createCard("Relación lineal esfuerzo-deformación");
  const epsilon = Number(payload.epsilon || 0.001);
  const sigma = Number(payload.sigma || (payload.E || 1) * epsilon);
  const x = Math.min(560, 80 + epsilon * 300000);
  const y = Math.max(30, 190 - sigma / 2_500_000);

  stage.append(
    createSvg(`
      <line x1="70" y1="190" x2="590" y2="190" stroke="#102a2b" stroke-width="2" />
      <line x1="70" y1="190" x2="70" y2="30" stroke="#102a2b" stroke-width="2" />
      <line x1="70" y1="190" x2="${x}" y2="${y}" stroke="#0d5c63" stroke-width="5" />
      <circle cx="${x}" cy="${y}" r="7" fill="#b85c38" />
      <text x="590" y="214" text-anchor="end" fill="#102a2b" font-size="16" font-family="Trebuchet MS">epsilon</text>
      <text x="32" y="40" fill="#102a2b" font-size="16" font-family="Trebuchet MS">sigma</text>
      <text x="${Math.min(520, x + 14)}" y="${Math.max(26, y - 10)}" fill="#102a2b" font-size="16" font-family="Trebuchet MS">(${formatNumber(epsilon)}, ${formatNumber(sigma / 1_000_000)} MPa)</text>
    `, "0 0 640 240"),
  );
  target.append(
    wrapper,
    makeLegend([
      { color: "#0d5c63", label: "Recta elástica" },
      { color: "#b85c38", label: "Estado calculado" },
    ]),
  );
};

const renderLever = (target, payload) => {
  const { wrapper, stage } = createCard("Brazo de palanca y momento");
  const armEnd = Math.min(520, 180 + payload.distance * 110);
  stage.append(
    createSvg(`
      <circle cx="140" cy="170" r="24" fill="#0d5c63" />
      <line x1="140" y1="170" x2="${armEnd}" y2="110" stroke="#102a2b" stroke-width="12" stroke-linecap="round" />
      <line x1="${armEnd}" y1="40" x2="${armEnd}" y2="110" stroke="#b85c38" stroke-width="8" />
      <polygon points="${armEnd},30 ${armEnd - 12},54 ${armEnd + 12},54" fill="#b85c38" />
      <path d="M 92 120 A 70 70 0 0 1 170 90" fill="none" stroke="#4a8e84" stroke-width="5" />
      <polygon points="172,94 154,90 164,104" fill="#4a8e84" />
      <text x="${armEnd + 14}" y="74" fill="#102a2b" font-size="16" font-family="Trebuchet MS">F = ${formatNumber(payload.force)} N</text>
      <text x="220" y="152" fill="#102a2b" font-size="16" font-family="Trebuchet MS">d = ${formatNumber(payload.distance)} m</text>
      <text x="106" y="228" fill="#102a2b" font-size="18" font-family="Rockwell">M = ${formatNumber(payload.moment)} N*m</text>
    `, "0 0 640 240"),
  );
  target.append(
    wrapper,
    makeLegend([
      { color: "#b85c38", label: "Fuerza aplicada" },
      { color: "#4a8e84", label: "Sentido de giro" },
    ]),
  );
};

const renderBeamCanvas = (stage, payload, mode) => {
  const canvas = createCanvas((ctx, width, height) => {
    const margin = 50;
    const baselineY = mode === "load" ? 120 : height / 2;
    const usableWidth = width - margin * 2;
    const xToCanvas = (x) => margin + (x / payload.span) * usableWidth;

    ctx.clearRect(0, 0, width, height);
    ctx.font = "14px Trebuchet MS";
    ctx.fillStyle = "#102a2b";
    ctx.strokeStyle = "#102a2b";

    if (mode === "load") {
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(margin, baselineY);
      ctx.lineTo(width - margin, baselineY);
      ctx.stroke();

      ctx.fillStyle = "#0d5c63";
      ctx.beginPath();
      ctx.moveTo(margin - 16, baselineY + 30);
      ctx.lineTo(margin, baselineY);
      ctx.lineTo(margin + 16, baselineY + 30);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = "#4a8e84";
      ctx.beginPath();
      ctx.arc(width - margin, baselineY + 18, 12, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = "#102a2b";
      ctx.fillText(`RA = ${formatNumber(payload.reactionA)} N`, margin - 8, baselineY + 60);
      ctx.fillText(`RB = ${formatNumber(payload.reactionB)} N`, width - margin - 76, baselineY + 60);

      if (payload.loadType === "point") {
        const loadX = xToCanvas(payload.position);
        ctx.strokeStyle = "#b85c38";
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.moveTo(loadX, 40);
        ctx.lineTo(loadX, baselineY - 8);
        ctx.stroke();

        ctx.fillStyle = "#b85c38";
        ctx.beginPath();
        ctx.moveTo(loadX, baselineY - 2);
        ctx.lineTo(loadX - 10, baselineY - 22);
        ctx.lineTo(loadX + 10, baselineY - 22);
        ctx.closePath();
        ctx.fill();
        ctx.fillText(`P = ${formatNumber(payload.load)} N`, loadX - 28, 28);
      } else {
        ctx.strokeStyle = "#b85c38";
        ctx.lineWidth = 2;
        for (let x = margin + 10; x < width - margin; x += 32) {
          ctx.beginPath();
          ctx.moveTo(x, 36);
          ctx.lineTo(x, baselineY - 8);
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(x, baselineY - 8);
          ctx.lineTo(x - 8, baselineY - 22);
          ctx.lineTo(x + 8, baselineY - 22);
          ctx.closePath();
          ctx.fill();
        }
        ctx.fillText(`w = ${formatNumber(payload.load)} N/m`, margin, 24);
      }
    } else {
      const key = mode === "shear" ? "shear" : "moment";
      const values = payload.points.map((point) => point[key]);
      const maxAbs = Math.max(...values.map((value) => Math.abs(value)), 1);
      const scale = (height / 2 - 28) / maxAbs;

      // The filled shape makes sign changes and peak values easier to spot than a line alone.
      ctx.strokeStyle = "#d7dfdf";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(margin, baselineY);
      ctx.lineTo(width - margin, baselineY);
      ctx.stroke();

      ctx.strokeStyle = mode === "shear" ? "#0d5c63" : "#b85c38";
      ctx.fillStyle = mode === "shear" ? "rgba(13,92,99,0.18)" : "rgba(184,92,56,0.18)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      payload.points.forEach((point, index) => {
        const x = xToCanvas(point.x);
        const y = baselineY - point[key] * scale;
        if (index === 0) {
          ctx.moveTo(x, baselineY);
          ctx.lineTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });
      ctx.lineTo(width - margin, baselineY);
      ctx.closePath();
      ctx.fill();

      ctx.beginPath();
      payload.points.forEach((point, index) => {
        const x = xToCanvas(point.x);
        const y = baselineY - point[key] * scale;
        if (index === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });
      ctx.stroke();
      ctx.fillStyle = "#102a2b";
      ctx.fillText(mode === "shear" ? "Diagrama de cortante V(x)" : "Diagrama de momento M(x)", margin, 24);
    }
  }, 680, 260);

  stage.append(canvas);
};

const renderBeam = (target, payload) => {
  const loadCard = createCard("Diagrama de carga y apoyos");
  renderBeamCanvas(loadCard.stage, payload, "load");

  const shearCard = createCard("Diagrama de cortante");
  renderBeamCanvas(shearCard.stage, payload, "shear");

  const momentCard = createCard("Diagrama de momento flector");
  renderBeamCanvas(momentCard.stage, payload, "moment");

  target.append(
    loadCard.wrapper,
    shearCard.wrapper,
    momentCard.wrapper,
    makeLegend([
      { color: "#b85c38", label: "Cargas aplicadas" },
      { color: "#0d5c63", label: "Cortante" },
      { color: "#4a8e84", label: "Apoyos" },
    ]),
  );
};

const renderDeflection = (target, payload) => {
  const { wrapper, stage } = createCard("Curva simplificada de deflexión");
  const depth = Math.min(90, 24 + payload.delta * 5000);
  const path = `M 70 90 Q 320 ${90 + depth} 570 90`;
  stage.append(
    createSvg(`
      <line x1="70" y1="90" x2="570" y2="90" stroke="#d7dfdf" stroke-width="4" stroke-dasharray="8 6" />
      <path d="${path}" fill="none" stroke="#0d5c63" stroke-width="6" />
      <line x1="320" y1="90" x2="320" y2="${90 + depth}" stroke="#b85c38" stroke-width="4" stroke-dasharray="6 6" />
      <text x="320" y="${118 + depth}" text-anchor="middle" fill="#102a2b" font-size="16" font-family="Trebuchet MS">delta max = ${formatNumber(payload.delta * 1000)} mm</text>
      <text x="70" y="44" fill="#102a2b" font-size="16" font-family="Trebuchet MS">L = ${formatNumber(payload.span)} m</text>
    `, "0 0 640 240"),
  );
  target.append(wrapper, makeLegend([{ color: "#0d5c63", label: "Forma deformada" }]));
};

const renderInertiaShape = (target, payload) => {
  const { wrapper, stage } = createCard("Geometría de la sección");
  let svgContent = "";

  if (payload.shape === "rectangle") {
    svgContent = `
      <rect x="220" y="50" width="200" height="140" fill="#0d5c63" fill-opacity="0.14" stroke="#0d5c63" stroke-width="4" />
      <text x="320" y="36" text-anchor="middle" fill="#102a2b" font-size="16" font-family="Trebuchet MS">b = ${formatNumber(payload.base)} m</text>
      <text x="438" y="125" fill="#102a2b" font-size="16" font-family="Trebuchet MS">h = ${formatNumber(payload.height)} m</text>
    `;
  } else if (payload.shape === "circle") {
    svgContent = `
      <circle cx="320" cy="120" r="80" fill="#0d5c63" fill-opacity="0.14" stroke="#0d5c63" stroke-width="4" />
      <line x1="240" y1="120" x2="400" y2="120" stroke="#b85c38" stroke-width="3" stroke-dasharray="6 6" />
      <text x="320" y="36" text-anchor="middle" fill="#102a2b" font-size="16" font-family="Trebuchet MS">d = ${formatNumber(payload.diameter)} m</text>
    `;
  } else {
    svgContent = `
      <polygon points="200,190 440,190 320,50" fill="#0d5c63" fill-opacity="0.14" stroke="#0d5c63" stroke-width="4" />
      <text x="320" y="214" text-anchor="middle" fill="#102a2b" font-size="16" font-family="Trebuchet MS">b = ${formatNumber(payload.base)} m</text>
      <text x="448" y="126" fill="#102a2b" font-size="16" font-family="Trebuchet MS">h = ${formatNumber(payload.height)} m</text>
    `;
  }

  stage.append(createSvg(svgContent, "0 0 640 240"));
  target.append(wrapper, makeLegend([{ color: "#0d5c63", label: "Sección analizada" }]));
};

const renderConversion = (target, payload) => {
  const { wrapper, stage } = createCard("Escala de conversión");
  stage.append(
    createSvg(`
      <rect x="80" y="80" width="210" height="80" rx="24" fill="#e7f1f0" stroke="#0d5c63" stroke-width="2" />
      <rect x="350" y="80" width="210" height="80" rx="24" fill="#fff0ea" stroke="#b85c38" stroke-width="2" />
      <path d="M 305 120 L 340 120" stroke="#102a2b" stroke-width="4" />
      <polygon points="340,120 324,110 324,130" fill="#102a2b" />
      <text x="185" y="112" text-anchor="middle" fill="#102a2b" font-size="16" font-family="Trebuchet MS">Entrada</text>
      <text x="185" y="136" text-anchor="middle" fill="#102a2b" font-size="22" font-family="Rockwell">${formatNumber(payload.inputValue)} ${payload.inputUnit}</text>
      <text x="455" y="112" text-anchor="middle" fill="#102a2b" font-size="16" font-family="Trebuchet MS">Salida</text>
      <text x="455" y="136" text-anchor="middle" fill="#102a2b" font-size="22" font-family="Rockwell">${formatNumber(payload.outputValue)} ${payload.outputUnit}</text>
    `, "0 0 640 240"),
  );
  target.append(
    wrapper,
    makeLegend([
      { color: "#0d5c63", label: "Unidad de entrada" },
      { color: "#b85c38", label: "Unidad convertida" },
    ]),
  );
};

export const renderVisual = (target, visual) => {
  if (!visual) {
    target.className = "visual-box empty-state";
    target.textContent = "Este módulo no requiere una visualización específica todavía.";
    return;
  }

  clearNode(target);
  target.className = "visual-box";

  const renderers = {
    stressBar: renderStressBar,
    strainGauge: renderStrainGauge,
    hookeLine: renderHooke,
    lever: renderLever,
    beam: renderBeam,
    deflection: renderDeflection,
    inertiaShape: renderInertiaShape,
    conversion: renderConversion,
  };

  const renderer = renderers[visual.type];
  if (!renderer) {
    target.className = "visual-box empty-state";
    target.textContent = "La visualización para este módulo estará disponible en una próxima iteración.";
    return;
  }

  renderer(target, visual.payload);
};
